# Point of Sale System - Web Application v1.1
CSS326 Database Programming Laboratory - Project

![alt text](https://i.imgur.com/RCVQ1T8.jpg)
